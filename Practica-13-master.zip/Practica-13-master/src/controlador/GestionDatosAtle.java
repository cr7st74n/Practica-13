package controlador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import modelo.Competencia;
import modelo.Resultado;
import modelo.Atleta;

public class GestionDatosAtle {
	private List<Atleta> atletas;
	private List<Competencia> competencias;
	private List<Resultado> resultados;
private String pathPersona="Datos/Atleta.dat";
private int cont;
//estamos ajsja
public GestionDatosAtle(List<Atleta> atletas, List<Competencia> competencias, List<Resultado> resultados, String pathPersona) {
	super();
	this.atletas = atletas;
	this.competencias = competencias;
	this.resultados = resultados;
	this.pathPersona = pathPersona;
}

public GestionDatosAtle() {
	atletas = new ArrayList<Atleta>();
	competencias = new ArrayList<Competencia>();
	resultados = new ArrayList<Resultado>();
}

public void newAtleta(String nombreA,String apellidoA,String edad,String numeroCo,String lugarPos) throws IOException{
	Atleta re=new Atleta();
   re.setNombre(nombreA);
   re.setApellido(apellidoA);
	re.setEdad(edad);
		
	Competencia ar=new Competencia();
	ar.setNumero(numeroCo);
	competencias.add(ar);
    re.setCompetencias(ar);

    Resultado au=new Resultado();
  au.setPrimerLug(lugarPos);
    resultados.add(au);
	ar.setResultados(au);
	
	atletas.add(re);
	
try{
	FileOutputStream file=new FileOutputStream(pathPersona,true);
	DataOutputStream out=new DataOutputStream(file);
	
	out.writeUTF(nombreA);
	out.writeUTF(apellidoA);
	out.writeUTF(edad);
	out.writeUTF(numeroCo);
	out.writeUTF(lugarPos);
	
	out.close();
	}catch(IOException e){
		e.printStackTrace();    
	}
cont++;
}

public String leerArchivos() throws Exception {
	FileInputStream lectura=null;
	DataInputStream entrada=null;
	try{
		String ruta=pathPersona;
		lectura=new FileInputStream(ruta);
		entrada=new DataInputStream(lectura);
		
		while(true){
			String nom=entrada.readUTF();
			String nom1=entrada.readUTF();
			String nom2=entrada.readUTF();
			String nom3=entrada.readUTF();
			String nom4=entrada.readUTF();
			
			String nom5=entrada.readUTF();
			String nom6=entrada.readUTF();
			String nom7=entrada.readUTF();
			String nom8=entrada.readUTF();
			String nom9=entrada.readUTF();
			
			System.out.println(nom);
			System.out.println(nom1);
			System.out.println(nom2);
			System.out.println(nom3);
			System.out.println(nom4);
			
			System.out.println(nom5);
			System.out.println(nom6);
			System.out.println(nom7);
			System.out.println(nom8);
			System.out.println(nom9);
			String imp= nom+ " ; "+nom1+" ; "+nom2+" ; "+nom3+" ; "+nom4;
	    	String imp1= nom5+ " ; "+nom6+" ; "+nom7+" ; "+nom8+" ; "+nom9;
	    	return imp+"\n"+imp1;
		}
	}catch(Exception e1){
		e1.printStackTrace();
	}
	return null;
	
}
public int buscarAtleta(String numeroJug){
	
		for (int i = 0; i < competencias.size(); i++) {
			Competencia car = competencias.get(i);
			if (car.getNumero().equals(numeroJug)) {
						return 0;
			}
		}
		return 1;
}
public List<Atleta> getAtletas(){
	return atletas;
	
}
}
