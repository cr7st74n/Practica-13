package vista;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MiVentana m=new MiVentana();
m.setVisible(true);

	}
}
